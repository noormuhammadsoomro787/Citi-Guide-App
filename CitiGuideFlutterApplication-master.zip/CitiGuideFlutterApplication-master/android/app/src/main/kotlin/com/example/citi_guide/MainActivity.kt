package com.example.citi_guide

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
